package test;

import java.util.ArrayList;
import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=0;
		System.out.print("印菱形+四種直角三角形 Input N = ");
		Scanner scanner = new Scanner(System.in);
		n=scanner.nextInt();
		System.out.println("菱形:");
		for(int i=1;i<n;i=i+1)//印菱形
		{
			for(int j=1;j<=n;j=j+1)
			{
				if(j>i) {System.out.print(" ");}
			}
			for(int k=1;k<=i*2-1;k=k+1)
			{
				System.out.print("*");
			}
			System.out.println("");
		}
		for(int i=1;i<=n;i=i+1)
		{
			for(int j=1;j<=n;j=j+1)
			{
				if(j<i) {System.out.print(" ");}
			}
			for(int k=1;k<=n*2-1;k=k+1)
			{
				if(k>=i*2-1) {System.out.print("*");}
			}
			System.out.println("");
		}
		/////////////////////////印菱形/////////////////////////////////////
		System.out.print("左邊直角三角形:");
		for(int i=0;i<n;i=i+1)//左邊直角三角形
		{
			for(int j=0;j<n;j=j+1)
			{
				if(i>j) {System.out.print("*");}//i>=j
			}
			System.out.println();
		}
		
		for(int i=0;i<n;i=i+1)
		{
			for(int j=0;j<n;j=j+1)
			{
				if(i<=j) {System.out.print("*");}
			}
			System.out.println();
		}
		System.out.println();
		///////////////////印左邊直角三角形///////////////////////////
		System.out.println("右邊直角三角形:");
		for(int i=0;i<n;i=i+1)
		{
			for(int j=0;j<n;j=j+1)
			{
				if(i>=n-j-1) {System.out.print("*");}
				else {System.out.print(" ");}
			}
			System.out.println();
		}
		for(int i=0;i<n;i=i+1)
		{
			for(int j=0;j<n;j=j+1)
			{
				if(i<j) {System.out.print("*");}//i<=j
				else {System.out.print(" ");}
			}
			System.out.println();
		}
		///////////////////印右邊直角三角形///////////////////////////
		System.out.println("動態陣列+隨機產生數字0~100排序: ");
		ArrayList<Integer> arraylist = new ArrayList<Integer>();//動態陣列產生
		int change=0;
		for(int i=0;i<n;i=i+1)
		{
			arraylist.add((int)(Math.random()*100+1));//產生1~100亂數
		}
		System.out.println(arraylist);
		//Collections.sort(arraylist);
		//System.out.println(arraylist); ArrayList排序函式
		for(int i=0;i<n;i=i+1)
		{
			for(int j=0;j<n;j=j+1)
			{
				if((int)(arraylist.get(i))<(int)(arraylist.get(j)))//動態陣列為obj要轉型
				{
					change=(int)(arraylist.get(i));
					arraylist.set(i, (int)(arraylist.get(j)));
					arraylist.set(j, change);//動態陣列修改set(索引值,值)
				}
			}
		}
		System.out.print(arraylist);
		/////////////////以上動態陣列小~大排序+產生亂數//////////////////////////
	}
}

