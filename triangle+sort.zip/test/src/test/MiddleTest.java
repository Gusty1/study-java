package test;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MiddleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line="";
		String n = "\n";
		String tab = "\t";
		ArrayList<String> ii =new ArrayList<String>();
		try (	FileInputStream fis = new FileInputStream("C:\\JAVA\\video_games.csv");
                InputStreamReader isr = new InputStreamReader(fis, "UTF8");
				BufferedReader br =new BufferedReader(isr);
				FileOutputStream fos = new FileOutputStream("C:\\JAVA\\video_games.txt");
	            BufferedOutputStream bos = new BufferedOutputStream(fos);
			) {
			
    		while(line !=null)
    		{
    			line = br.readLine();
    			if(line==null) {break;}
    			String[] parts = line.split(",");
    			
    			ii.add(parts[0]);
    			
    			/*for(int i=0 ;i<parts.length;i=i+1)
    			{System.out.print(parts[i]+"\t");}
    			System.out.println();*/
    			for(int i=0 ;i<parts.length;i=i+1)
    			{	
    				byte buf[] = parts[i].getBytes();
    				bos.write(buf);
    				bos.write(tab.getBytes());
    			}
    			bos.write(n.getBytes());
    		}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO: handle exception
		}
		for(int i=0; i<ii.size();i=i+1 )
		{
			for(int j=i+1;j<ii.size(); j=j+1)
			{
				if(ii.get(i).equals(ii.get(j)))
				{
					System.out.println(ii.get(i));
				}
			}
		}
	}
}
